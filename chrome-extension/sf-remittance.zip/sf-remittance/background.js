import { getConfig, setStatus } from './store.js'
import { fetchQueue, postResult, fetchNoteQueue, postNoteResult, postVendorOrders, postAlert } from './app-api.js'
import { applyOne } from './sf.js'
import { postNote } from './sf-note.js'

const ALARM = 'sf-remittance-poll'
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

async function scheduleAlarm() {
  const { pollMinutes } = await getConfig()
  chrome.alarms.create(ALARM, { periodInMinutes: Math.max(1, Number(pollMinutes) || 10) })
}

const SF_RECOVER_ALARM = 'sf-session-recover'
const SF_KEEPALIVE_ALARM = 'sf-session-keepalive'
const CRAWL_TZ = 'America/Los_Angeles'
const CRAWL_TIMEOUT_MS = 20 * 60 * 1000

// ── Scheduled vendor-portal crawls (Genie + Clopay share one engine) ────────
// An always-on office PC runs these: hourly during work hours (incremental — just
// new/changed orders) plus a nightly full backfill. The alarm fires hourly and
// the handler decides what (if anything) to run based on the PT clock. Each crawl
// opens a background tab to the order list; the content script does the work and
// signals completion, then we close the tab. A timeout alarm force-closes a tab
// that never finishes. State lives in chrome.storage (the MV3 worker is ephemeral).
//
// Every crawler is one descriptor here — its portal URL, its own storage keys /
// alarm names (so Genie and Clopay never step on each other), the option flags
// that gate it, and the login/alert source names. All the machinery below is
// parameterized by the descriptor, so adding a portal is one entry + its content
// script.
const CRAWLERS = {
  genie: {
    name: 'genie', vendor: 'genie_thd',
    listUrl: 'https://install.openings.net/webcenter/portal/installerconnect/orderlist',
    stateKey: 'genieCrawl', modeKey: 'genieCrawlMode',
    alarm: 'genie-crawl', timeoutAlarm: 'genie-crawl-timeout',
    scheduleFlag: 'genieScheduleEnabled', enabledFlag: 'genieEnabled',
    loginFlag: 'genie-login-detected', alertSource: 'genie',
  },
  clopay: {
    name: 'clopay', vendor: 'clopay_hd',
    // Start at the Clopay IAM login URL (per Castle — this stable entry point does
    // not expire): content-login signs in on prod-iam, the OIDC flow returns to
    // cca.clopay.com, and content-clopay's cca handler clicks HD Program →
    // hdprogram.clopay.com/orders. Opening /orders directly does NOT bounce to
    // login, so a logged-out crawl would just sit on a blank page.
    listUrl: 'https://prod-iam.clopay.com/Account/Login?ReturnUrl=%2Fconnect%2Fauthorize%2Fcallback%3Fresponse_type%3Dcode%26client_id%3D6f5a9fb9039d422abebe546ef935951b%26state%3DT2dVTzlsfkt4LWJwdDdyYm1tOGJIM1BFNWtmTnZCQ1pfaDFhUmJpLVV4MmlH%26redirect_uri%3Dhttps%253A%252F%252Fcca.clopay.com%252Fsignin-oidc%26scope%3Dopenid%2520profile%26code_challenge%3DFemCme6P6lp59gS8nDRLwOnnnyZgSAWtuHKdUlpHcf8%26code_challenge_method%3DS256%26nonce%3DT2dVTzlsfkt4LWJwdDdyYm1tOGJIM1BFNWtmTnZCQ1pfaDFhUmJpLVV4MmlH',
    stateKey: 'clopayCrawl', modeKey: 'clopayCrawlMode',
    alarm: 'clopay-crawl', timeoutAlarm: 'clopay-crawl-timeout',
    scheduleFlag: 'clopayScheduleEnabled', enabledFlag: 'clopayEnabled',
    loginFlag: 'clopay-login-detected', alertSource: 'clopay',
  },
}
const crawlerByName = (name) => CRAWLERS[name] || null
const crawlerByLoginFlag = (flag) => Object.values(CRAWLERS).find(c => c.loginFlag === flag) || null
const crawlerByIngestType = (type) => CRAWLERS[type] || null // content scripts send type === crawler name

chrome.runtime.onInstalled.addListener(() => { scheduleAlarm(); scheduleAllCrawls(); scheduleSfKeepalive() })
chrome.runtime.onStartup.addListener(() => { scheduleAlarm(); scheduleAllCrawls(); scheduleSfKeepalive() })
chrome.alarms.onAlarm.addListener(a => {
  if (a.name === ALARM) return run('alarm')
  if (a.name === SF_RECOVER_ALARM) return finishSfRecover()
  if (a.name === SF_KEEPALIVE_ALARM) return maybeSfKeepalive()
  for (const c of Object.values(CRAWLERS)) {
    if (a.name === c.alarm) return maybeScheduledCrawl(c)
    if (a.name === c.timeoutAlarm) return onCrawlTimeout(c)
  }
})

// A scheduled crawl that never signalled done → it stalled. Close its tab and
// alert, so a silently-broken crawl doesn't go unnoticed.
async function onCrawlTimeout(c) {
  const state = (await chrome.storage.local.get(c.stateKey))[c.stateKey]
  await finishCrawl(c, 'timeout')
  if (state) { setBadge('!'); await notifyAlert(c.alertSource, 'error', 'scheduled crawl did not finish (timed out)') }
}

// delayInMinutes:1 so the schedule also fires ~1 min after Chrome start / an
// extension reload — otherwise each reload restarts a full 60-min countdown and a
// machine that's reloaded/restarted often could go a long time without a crawl.
function scheduleAllCrawls() { for (const c of Object.values(CRAWLERS)) chrome.alarms.create(c.alarm, { delayInMinutes: 1, periodInMinutes: 60 }) }
function scheduleSfKeepalive() { chrome.alarms.create(SF_KEEPALIVE_ALARM, { delayInMinutes: 2, periodInMinutes: 60 }) }

function ptNow() {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat('en-US', { timeZone: CRAWL_TZ, weekday: 'short', hour: '2-digit', hour12: false })
      .formatToParts(new Date()).map(p => [p.type, p.value]))
  return { hour: Number(parts.hour) % 24, weekday: parts.weekday }
}

async function maybeScheduledCrawl(c) {
  const cfg = await getConfig()
  if (!cfg[c.scheduleFlag]) return
  const { hour, weekday } = ptNow()
  const workday = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].includes(weekday)
  let mode = null
  if (hour === 3) mode = 'full'                                   // nightly full backfill ~3am PT
  else if (workday && hour >= 7 && hour <= 18) mode = 'incremental' // 7am–6pm Mon–Sat
  if (!mode) return
  await startCrawl(c, mode)
}

async function tabExists(tabId) {
  if (tabId == null) return false
  try { await chrome.tabs.get(tabId); return true } catch { return false }
}

// mode: 'full' | 'incremental'. force:true (the manual button) always starts a
// fresh crawl. Returns { started, reason }.
async function startCrawl(c, mode, { force = false } = {}) {
  const state = (await chrome.storage.local.get(c.stateKey))[c.stateKey]
  // Only treat an existing crawl as "already running" if it's recent AND its tab
  // is actually still open. Stale state (tab closed / worker died / a missed
  // 'done' message) must not block a new crawl — especially the manual button.
  if (state && !force && Date.now() - state.startedAt < CRAWL_TIMEOUT_MS && await tabExists(state.tabId)) {
    console.log(`[${c.name}] crawl already running`)
    return { started: false, reason: 'already running' }
  }
  // Force, or leftover state — tear down anything stale before starting fresh.
  if (state) {
    chrome.alarms.clear(c.timeoutAlarm)
    if (state.tabId != null) { try { await chrome.tabs.remove(state.tabId) } catch { /* already closed */ } }
  }
  await chrome.storage.local.set({ [c.modeKey]: mode })
  const tab = await chrome.tabs.create({ url: c.listUrl, active: false })
  await chrome.storage.local.set({ [c.stateKey]: { tabId: tab.id, mode, startedAt: Date.now() } })
  await setStatus({ source: `${c.name}-schedule`, mode, state: 'running' })
  chrome.alarms.create(c.timeoutAlarm, { when: Date.now() + CRAWL_TIMEOUT_MS })
  console.log(`[${c.name}] crawl started:`, mode, force ? '(forced)' : '')
  return { started: true }
}

async function finishCrawl(c, reason) {
  const state = (await chrome.storage.local.get(c.stateKey))[c.stateKey]
  chrome.alarms.clear(c.timeoutAlarm)
  await chrome.storage.local.remove([c.stateKey, c.modeKey])
  if (state && state.tabId != null && reason !== 'login') {
    try { await chrome.tabs.remove(state.tabId) } catch { /* already closed */ }
  }
  console.log(`[${c.name}] crawl finished:`, reason)
}

function setBadge(text) {
  try {
    chrome.action.setBadgeText({ text })
    if (text) chrome.action.setBadgeBackgroundColor({ color: '#b91c1c' })
  } catch { /* ignore */ }
}

// Email the chosen recipients about an automation problem (deduped server-side).
async function notifyAlert(source, kind, detail) {
  const cfg = await getConfig()
  if (!cfg.baseUrl || !cfg.token) return
  try { await postAlert(cfg.baseUrl, cfg.token, { source, kind, detail }) } catch (e) { console.warn('[alert] failed', e) }
}

// ── Keep the Service Fusion session warm ─────────────────────────────────────
// SF's session goes stale when nothing touches it in the browser — background
// fetches from the worker then come back non-JSON / bounced even though you're
// still "logged in". A quick navigation refreshes it. So we open
// admin.servicefusion.com in a background tab (which refreshes the session — and,
// if it HAS actually logged out, content-login.js signs back in with saved creds),
// then close it. Runs proactively every hour and reactively on a failed post.
const SF_RECOVER_MS = 45000
async function warmSfSession({ retry = false } = {}) {
  const { sfRecovering } = await chrome.storage.local.get('sfRecovering')
  if (sfRecovering && Date.now() - sfRecovering.at < 3 * 60 * 1000) return // one at a time
  const tab = await chrome.tabs.create({ url: 'https://admin.servicefusion.com/', active: false })
  await chrome.storage.local.set({ sfRecovering: { tabId: tab.id, at: Date.now(), retry } })
  chrome.alarms.create(SF_RECOVER_ALARM, { when: Date.now() + SF_RECOVER_MS })
  console.log('[sf] warming session via admin.servicefusion.com', retry ? '→ will retry queue' : '(keep-alive)')
}

async function finishSfRecover() {
  const { sfRecovering } = await chrome.storage.local.get('sfRecovering')
  await chrome.storage.local.remove('sfRecovering')
  if (sfRecovering && sfRecovering.tabId != null) { try { await chrome.tabs.remove(sfRecovering.tabId) } catch { /* already closed */ } }
  if (sfRecovering && sfRecovering.retry) { console.log('[sf] session refreshed → retrying queued work'); run('sf-recover') }
}

// Hourly proactive keep-alive (only when the background poll is on — i.e. SF
// automation is actually in use).
async function maybeSfKeepalive() {
  const cfg = await getConfig()
  if (!cfg.enabled) return
  await warmSfSession({ retry: false })
}

// Manual "Run now" from the popup.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'run-now') { run('manual').then(r => sendResponse(r)); return true }
})

// "Full <portal> crawl now" from the popup — same machinery as a scheduled full
// crawl (opens a background tab, details every order, closes when done), but on
// demand and regardless of the schedule/auto-detail toggles. One handler per
// crawler: 'genie-crawl-now', 'clopay-crawl-now', …
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const c = typeof msg?.type === 'string' && msg.type.endsWith('-crawl-now') ? crawlerByName(msg.type.slice(0, -'-crawl-now'.length)) : null
  if (!c) return
  ;(async () => {
    const cfg = await getConfig()
    if (!cfg.baseUrl || !cfg.token) { sendResponse({ ok: false, error: 'set Castle Admin URL + token in Options' }); return }
    setBadge('')
    // force:true — a manual click always opens a fresh crawl tab, even if stale
    // crawl state is lingering from a previous run.
    const r = await startCrawl(c, 'full', { force: true })
    sendResponse({ ok: !!r.started, error: r.started ? undefined : (r.reason || 'could not start') })
  })()
  return true
})

// A content script asks whether it's running in the extension's crawl tab, so it
// only auto-navigates the portal there (never in the user's own browsing).
// 'genie-crawl-tab?', 'clopay-crawl-tab?', …
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const c = typeof msg?.type === 'string' && msg.type.endsWith('-crawl-tab?') ? crawlerByName(msg.type.slice(0, -'-crawl-tab?'.length)) : null
  if (!c) return
  ;(async () => {
    const state = (await chrome.storage.local.get(c.stateKey))[c.stateKey]
    sendResponse({ isCrawlTab: !!(state && sender.tab && sender.tab.id === state.tabId) })
  })()
  return true
})

// Content scripts signal a scheduled crawl's outcome. 'genie-crawl-done',
// 'clopay-crawl-done', …
chrome.runtime.onMessage.addListener((msg, sender, _sendResponse) => {
  const done = typeof msg?.type === 'string' && msg.type.endsWith('-crawl-done') ? crawlerByName(msg.type.slice(0, -'-crawl-done'.length)) : null
  if (done) {
    ;(async () => {
      const state = (await chrome.storage.local.get(done.stateKey))[done.stateKey]
      // Only act on the crawl's own tab — a manual crawl in a user tab is ignored.
      if (state && sender.tab && sender.tab.id === state.tabId) { setBadge(''); await finishCrawl(done, 'done') }
    })()
    return
  }
  // A login page couldn't be signed into automatically (no saved credentials, or
  // they didn't take / MFA). Badge + email so someone signs in by hand.
  const LOGIN_ALERTS = {
    'genie-login-detected': 'genie',
    'clopay-login-detected': 'clopay',
    'sf-login-detected': 'service_fusion',
    'castle-login-detected': 'castle_admin',
  }
  if (msg?.type && LOGIN_ALERTS[msg.type]) {
    const source = LOGIN_ALERTS[msg.type]
    ;(async () => {
      await setStatus({ source: `${source}-login`, state: 'login_required' })
      setBadge('!')
      await notifyAlert(source, 'logged_out') // email chosen recipients (deduped server-side)
      // If this login belongs to a crawler and the logged-out page IS that
      // crawler's own tab, surface it for one-click login and end the crawl
      // (keeping the tab open so re-auth can happen).
      const c = crawlerByLoginFlag(msg.type)
      if (c) {
        const state = (await chrome.storage.local.get(c.stateKey))[c.stateKey]
        if (state && sender.tab && sender.tab.id === state.tabId) {
          try { await chrome.tabs.update(state.tabId, { active: true }) } catch { /* ignore */ }
          await finishCrawl(c, 'login')
        }
      }
    })()
    return
  }
})

// Orders scraped from a vendor portal (content-genie.js / content-clopay.js) →
// Castle Admin ingest. Independent of the SF poll loop; posts in the user's
// session using the same base URL + token. The content script sends the crawler
// name as `type` (e.g. 'genie', 'clopay') plus the vendor key.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const c = crawlerByIngestType(msg?.type)
  if (!c) return
  ;(async () => {
    const cfg = await getConfig()
    if (cfg[c.enabledFlag] === false) { sendResponse({ ok: false, error: `${c.name} disabled` }); return }
    if (!cfg.baseUrl || !cfg.token) { sendResponse({ ok: false, error: 'not configured' }); return }
    const orders = msg.kind === 'detail' ? [msg.payload] : (msg.payload || [])
    if (!orders.length) { sendResponse({ ok: true, skipped: 'no orders' }); return }
    try {
      const res = await postVendorOrders(cfg.baseUrl, cfg.token, msg.vendor, orders, { kind: msg.kind, mode: msg.mode })
      await setStatus({ source: c.name, vendor: msg.vendor, kind: msg.kind, ingest: res })
      console.log(`[sf-remittance] ${c.name} ingest`, res)
      sendResponse({ ok: true, ...res })
    } catch (e) {
      const error = e instanceof Error ? e.message : String(e)
      console.error(`[sf-remittance] ${c.name} ingest failed`, error)
      sendResponse({ ok: false, error })
    }
  })()
  return true // async response
})

/** Post queued SF job notes. Mirrors the payment pass: dry-run never writes back;
 *  live mode records every outcome. Returns { queued, posted, failed }. */
async function runNotes(cfg, log) {
  let queue
  try {
    queue = await fetchNoteQueue(cfg.baseUrl, cfg.token)
  } catch (e) {
    log.push({ noteQueueError: e instanceof Error ? e.message : String(e) })
    return { queued: 0, posted: 0, failed: 0 }
  }
  const { items } = queue
  console.log('[sf-remittance] note queue', { items: items.length })
  let posted = 0, failed = 0
  for (const item of items) {
    const res = await postNote(item, cfg)
    log.push({ noteId: item.id, event: item.event, jobNumber: item.jobNumber, jobId: item.sfJobId, ...res })
    if (!cfg.dryRun) {
      try {
        await postNoteResult(cfg.baseUrl, cfg.token, {
          id: item.id, ok: res.ok, sfResponse: { trace: res.trace, snippet: res.snippet }, error: res.ok ? undefined : res.error,
        })
      } catch (e) { log.push({ noteId: item.id, callbackError: String(e) }) }
    }
    res.ok ? posted++ : failed++
    // If SF is logged out, every remaining note fails the same way. Stop now so
    // we don't burn their retry budget or hammer SF — the app re-serves failed
    // notes, so they'll post on a later run once SF is signed back in.
    if (!res.ok && /session expired|redirected to login|failed to fetch|login form|got a login/i.test(res.error || '')) {
      log.push({ notesStoppedEarly: 'SF session appears logged out — remaining notes will retry next run' })
      break
    }
    await sleep(1500) // be gentle on SF
  }
  return { queued: items.length, posted, failed }
}

let running = false

export async function run(source) {
  if (running) return { ok: false, error: 'already running' }
  const cfg = await getConfig()
  // The "Enabled" toggle only gates the background poll; "Run now" always runs.
  if (source === 'alarm' && !cfg.enabled) { await setStatus({ source, skipped: 'background poll disabled' }); return { ok: false, error: 'disabled' } }
  if (!cfg.baseUrl || !cfg.token) { await setStatus({ source, error: 'not configured (set base URL + token in Options)' }); return { ok: false, error: 'not configured' } }

  running = true
  const log = []
  let applied = 0, failed = 0
  try {
    let queue
    try {
      queue = await fetchQueue(cfg.baseUrl, cfg.token)
    } catch (e) {
      const m = e instanceof Error ? e.message : String(e)
      throw new Error(/fetch/i.test(m) ? `Could not reach Castle Admin at ${cfg.baseUrl} (check the URL / that it's deployed). ${m}` : m)
    }
    const { items, skipped } = queue
    console.log('[sf-remittance] queue', { items: items.length, skipped })
    const isSfLogout = (err) => /session expired|redirected to login|got (?:a )?login|global search did not return json|login\?true/i.test(err || '')
    for (const item of items) {
      const res = await applyOne(item, cfg)
      log.push({ lineId: item.lineId, invoiceNumber: item.invoiceNumber, amount: item.amount, ...res })
      // SF logged us out — this isn't a problem with the line, and nothing posted
      // (we fail before the payment). Leave the line 'approved' (don't record a
      // failure) so it retries after we sign back in, and stop the pass since the
      // rest would fail identically.
      if (!res.ok && isSfLogout(res.error)) {
        log.push({ stoppedEarly: 'SF session expired — lines left queued for retry after re-login' })
        break
      }
      // In dry-run we never write back (nothing is really posted). In live mode,
      // record both successes and failures so the app's audit log is accurate.
      if (!cfg.dryRun) {
        try {
          await postResult(cfg.baseUrl, cfg.token, {
            lineId: item.lineId, ok: res.ok, sfPaymentId: res.paymentId ?? null,
            sfResponse: { trace: res.trace }, error: res.ok ? undefined : res.error,
          })
        } catch (e) { log.push({ lineId: item.lineId, callbackError: String(e) }) }
      }
      res.ok ? applied++ : failed++
      await sleep(1500) // be gentle on SF
    }
    // Second pass: post any queued SF job notes (invoice-reminder audit trail,
    // etc.). Independent of the payment pass — a failure here never affects it.
    const notes = await runNotes(cfg, log)

    // Alert on SF trouble: a login-looking failure → logged_out; any other apply
    // failure → error. Deduped server-side so it's one email, not one per line.
    if (!cfg.dryRun) {
      const failures = log.filter(l => l.ok === false)
      const staleSf = failures.some(l => isSfLogout(l.error))
      if (staleSf) {
        setBadge('!')
        if (source === 'sf-recover') {
          // Already refreshed once and it still failed → genuinely needs a human.
          await notifyAlert('service_fusion', 'logged_out')
        } else {
          // Most often the SF session just needs a refresh — warm it and retry
          // silently. No email unless the retry also fails (above).
          await warmSfSession({ retry: true })
        }
      }
      else if (failures.length) { setBadge('!'); await notifyAlert('service_fusion', 'error', `${failures.length} remittance line(s) failed to post`) }
    }

    await setStatus({ source, dryRun: cfg.dryRun, queued: items.length, skipped: skipped ?? [], applied, failed, notes, log })
    console.log('[sf-remittance] run complete', { dryRun: cfg.dryRun, applied, failed, notes, log })
    return { ok: true, dryRun: cfg.dryRun, applied, failed, notes, log }
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e)
    await setStatus({ source, error, log })
    console.error('[sf-remittance] run failed', error)
    return { ok: false, error }
  } finally {
    running = false
  }
}
